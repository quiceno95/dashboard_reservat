import React, { useState, useEffect } from 'react';
import { ExperienceStats } from './ExperienceStats';
import { ExperienceTable } from './ExperienceTable';
import { ExperienceCharts } from './ExperienceCharts';
import { ExperienciaCompleta } from '../../types/experience';
import { experienceService } from '../../services/experienceService';
import { AlertCircle, CheckCircle, Plus, Download } from 'lucide-react';

export const ExperiencesSection: React.FC = () => {
  const [experiences, setExperiences] = useState<ExperienciaCompleta[]>([]);
  const [loading, setLoading] = useState(true);
  const [currentPage, setCurrentPage] = useState(1);
  const [pageSize, setPageSize] = useState(5);
  const [totalExperiences, setTotalExperiences] = useState(0);
  const [totalPages, setTotalPages] = useState(0);
  const [searchTerm, setSearchTerm] = useState('');
  const [isSearching, setIsSearching] = useState(false);
  const [notification, setNotification] = useState<{
    type: 'success' | 'error';
    message: string;
  } | null>(null);

  // Estados para estadísticas
  const [stats, setStats] = useState({
    total: 0,
    verificadas: 0,
    espanol: 0,
    ingles: 0
  });
  const [statsLoading, setStatsLoading] = useState(true);

  // Estados para gráficos
  const [difficultyDistribution, setDifficultyDistribution] = useState<{ difficulty: string; count: number }[]>([]);
  const [languageDistribution, setLanguageDistribution] = useState<{ language: string; count: number }[]>([]);
  const [chartsLoading, setChartsLoading] = useState(true);

  useEffect(() => {
    if (searchTerm.trim()) {
      handleSearch(searchTerm);
    } else {
      loadExperiences();
    }
    
    // Cargar estadísticas independientemente
    loadStats();
    
    // Cargar datos para gráficas
    loadChartsData();
  }, [currentPage, pageSize, searchTerm]);

  const loadExperiences = async () => {
    try {
      setLoading(true);
      console.log('📊 === CARGANDO EXPERIENCIAS ===');
      console.log('Parámetros:', { currentPage, pageSize });
      
      const experiencesData = await experienceService.getExperiences(currentPage, pageSize);
      
      console.log('📊 Respuesta del servicio:', {
        experiencias: experiencesData.experiencias?.length || 0,
        total: experiencesData.total,
        page: experiencesData.page,
        size: experiencesData.size
      });
      
      // Handle paginated response (siguiendo el patrón de usuarios)
      if (experiencesData && typeof experiencesData === 'object' && 'experiencias' in experiencesData) {
        setExperiences(experiencesData.experiencias || []);
        setTotalExperiences(experiencesData.total || 0);
        setTotalPages(Math.ceil((experiencesData.total || 0) / pageSize));
      } else if (Array.isArray(experiencesData)) {
        // Fallback for non-paginated response
        setExperiences(experiencesData);
        setTotalExperiences(experiencesData.length);
        setTotalPages(1);
      } else {
        setExperiences([]);
        setTotalExperiences(0);
        setTotalPages(0);
      }
      
      // Log después de actualizar el estado
      setTimeout(() => {
        console.log('📊 Estado final actualizado:', {
          experienciasEnTabla: experiences.length,
          totalExperiences,
          totalPages,
          currentPage,
          pageSize
        });
      }, 100);
    } catch (error) {
      console.error('Error cargando experiencias:', error);
      setExperiences([]);
      setTotalExperiences(0);
      setTotalPages(0);
      showNotification('error', 'Error al cargar las experiencias');
    } finally {
      setLoading(false);
    }
  };

  const loadStats = async () => {
    try {
      setStatsLoading(true);
      console.log('📊 Cargando estadísticas de experiencias...');
      const statsData = await experienceService.getExperienceStats();
      console.log('📊 Estadísticas recibidas:', statsData);
      setStats(statsData);
    } catch (error) {
      console.error('Error cargando estadísticas:', error);
      setStats({
        total: 0,
        verificadas: 0,
        espanol: 0,
        ingles: 0
      });
    } finally {
      setStatsLoading(false);
    }
  };

  const loadChartsData = async () => {
    try {
      setChartsLoading(true);
      console.log('📊 Cargando datos para gráficas de experiencias...');
      
      const allExperiencesData = await experienceService.getExperiences(1, 1000);
      const allExperiences = allExperiencesData.experiencias || [];
      
      console.log('📊 Total de experiencias para gráficas:', allExperiences.length);
      
      // Procesar distribución por dificultad
      const difficultyData = processDifficultyDistribution(allExperiences);
      setDifficultyDistribution(difficultyData);
      
      // Procesar distribución por idioma
      const languageData = processLanguageDistribution(allExperiences);
      setLanguageDistribution(languageData);
      
      console.log('📊 Datos de dificultad procesados:', difficultyData);
      console.log('📊 Datos de idioma procesados:', languageData);
    } catch (error) {
      console.error('Error cargando datos para gráficas:', error);
      setDifficultyDistribution([]);
      setLanguageDistribution([]);
    } finally {
      setChartsLoading(false);
    }
  };

  const processDifficultyDistribution = (experiences: ExperienciaCompleta[]): { difficulty: string; count: number }[] => {
    const difficultyCount: { [key: string]: number } = {};
    
    experiences.forEach(exp => {
      const difficulty = exp.dificultad.toLowerCase();
      difficultyCount[difficulty] = (difficultyCount[difficulty] || 0) + 1;
    });
    
    return Object.entries(difficultyCount).map(([difficulty, count]) => ({
      difficulty,
      count
    })).sort((a, b) => b.count - a.count);
  };

  const processLanguageDistribution = (experiences: ExperienciaCompleta[]): { language: string; count: number }[] => {
    const languageCount: { [key: string]: number } = {};
    
    experiences.forEach(exp => {
      const language = exp.idioma.toLowerCase();
      languageCount[language] = (languageCount[language] || 0) + 1;
    });
    
    return Object.entries(languageCount).map(([language, count]) => ({
      language,
      count
    })).sort((a, b) => b.count - a.count);
  };

  const handleSearch = async (term: string) => {
    if (!term.trim()) {
      // Si no hay término de búsqueda, cargar experiencias normalmente
      setIsSearching(false);
      setSearchTerm('');
      loadExperiences();
      return;
    }

    try {
      setIsSearching(true);
      setLoading(true);
      
      console.log('🔍 Iniciando búsqueda global de experiencias:', term);
      
      // Obtener todas las experiencias para búsqueda local (siguiendo patrón de usuarios)
      const allExperiencesData = await experienceService.getExperiences(1, 1000);
      const allExperiences = Array.isArray(allExperiencesData) ? allExperiencesData : allExperiencesData.experiencias || [];
      
      // Filtrar localmente
      const filteredExperiences = allExperiences.filter(exp =>
        exp.proveedor_nombre.toLowerCase().includes(term.toLowerCase()) ||
        exp.proveedor_ciudad.toLowerCase().includes(term.toLowerCase()) ||
        exp.proveedor_pais.toLowerCase().includes(term.toLowerCase()) ||
        exp.idioma.toLowerCase().includes(term.toLowerCase()) ||
        exp.dificultad.toLowerCase().includes(term.toLowerCase()) ||
        exp.punto_de_encuentro.toLowerCase().includes(term.toLowerCase())
      );
      
      // Aplicar paginación manual
      const startIndex = (currentPage - 1) * pageSize;
      const endIndex = startIndex + pageSize;
      const paginatedResults = filteredExperiences.slice(startIndex, endIndex);
      
      setExperiences(paginatedResults);
      setTotalExperiences(filteredExperiences.length);
      setTotalPages(Math.ceil(filteredExperiences.length / pageSize));
      
      console.log(`✅ Búsqueda local completada: ${filteredExperiences.length} resultados encontrados`);
      
      if (filteredExperiences.length === 0) {
        showNotification('error', `No se encontraron experiencias que coincidan con "${term}"`);
      }
    } catch (error) {
      console.error('Error en búsqueda local:', error);
      setExperiences([]);
      setTotalExperiences(0);
      setTotalPages(0);
      showNotification('error', 'Error al buscar experiencias');
    } finally {
      setLoading(false);
    }
  };

  const handleSearchChange = (term: string) => {
    setSearchTerm(term);
    setCurrentPage(1); // Reset to first page when searching
    
    if (!term.trim()) {
      setIsSearching(false);
      loadExperiences();
    } else {
      setIsSearching(true);
    }
  };

  const clearSearch = () => {
    setSearchTerm('');
    setIsSearching(false);
    setCurrentPage(1);
    loadExperiences();
  };

  const handlePageChange = (page: number) => {
    console.log('📄 Cambiando a página:', page);
    setCurrentPage(page);
  };

  const handlePageSizeChange = (size: number) => {
    console.log('📏 Cambiando tamaño de página:', size);
    setPageSize(size);
    setCurrentPage(1); // Reset to first page when changing page size
  };

  const handleDataChange = () => {
    console.log('📊 Datos actualizados, recargando tabla...');
    // Recargar solo los datos necesarios
    loadExperiences();
    loadStats();
  };

  const showNotification = (type: 'success' | 'error', message: string) => {
    setNotification({ type, message });
    setTimeout(() => setNotification(null), 5000);
  };

  // Funciones estáticas para los botones (sin funcionalidad por ahora)
  const handleExportExperiences = () => {
    showNotification('success', 'Función de exportación en desarrollo');
  };

  const handleCreateExperience = () => {
    showNotification('success', 'Función de creación en desarrollo');
  };

  return (
    <div className="space-y-8">
      {/* Notification */}
      {notification && (
        <div className={`fixed top-4 right-4 z-50 flex items-center space-x-2 px-4 py-3 rounded-lg shadow-lg ${
          notification.type === 'success' 
            ? 'bg-green-50 text-green-800 border border-green-200' 
            : 'bg-red-50 text-red-800 border border-red-200'
        }`}>
          {notification.type === 'success' ? (
            <CheckCircle className="h-5 w-5" />
          ) : (
            <AlertCircle className="h-5 w-5" />
          )}
          <span className="font-medium">{notification.message}</span>
        </div>
      )}

      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Gestión de Experiencias</h1>
          <p className="text-gray-600 mt-2">
            Administra todas las experiencias y tours del sistema
          </p>
        </div>
        <div className="flex items-center space-x-3">
          <button
            onClick={handleExportExperiences}
            className="flex items-center space-x-2 px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 transition-colors font-medium"
          >
            <Download className="h-5 w-5" />
            <span>Exportar Experiencias</span>
          </button>
          <button
            onClick={handleCreateExperience}
            className="flex items-center space-x-2 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors font-medium"
          >
            <Plus className="h-5 w-5" />
            <span>Crear Experiencia</span>
          </button>
        </div>
      </div>

      {/* Stats */}
      <ExperienceStats
        totalExperiences={stats.total}
        verificadas={stats.verificadas}
        espanol={stats.espanol}
        ingles={stats.ingles}
        loading={statsLoading}
      />

      {/* Experiences Table */}
      <ExperienceTable
        experiences={experiences}
        searchTerm={searchTerm}
        isSearching={isSearching}
        onSearchChange={handleSearchChange}
        onClearSearch={clearSearch}
        loading={loading}
        currentPage={currentPage}
        totalPages={totalPages}
        totalExperiences={totalExperiences}
        pageSize={pageSize}
        onPageChange={handlePageChange}
        onPageSizeChange={handlePageSizeChange}
        onDataChange={handleDataChange}
      />

      {/* Charts */}
      <ExperienceCharts
        difficultyDistribution={difficultyDistribution}
        languageDistribution={languageDistribution}
        chartsLoading={chartsLoading}
      />
    </div>
  );
};